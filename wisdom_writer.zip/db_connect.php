<?PHP

$connect=mysqli_connect('localhost','root','','wisdomwriter');
//$connect=mysqli_connect('localhost','id14366822_wisdomwriter_jay','uy#Q2y-QPAbl!f66','id14366822_wisdomwriter');
?>